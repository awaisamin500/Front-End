function myfunction() {

			document.getElementById('para').innerHTML="changed";
		}